<div class="logo">
    Guardabosques
</div>