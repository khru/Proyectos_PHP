<div class="container">
	<p>¿Seguro que quieres borrar esta revista?</p>
	<p>Desaparecerán todos los datos y no podrán recuperarse posteriormente(pero no se eliminarán los archivos en el servidor)</p>
</div>