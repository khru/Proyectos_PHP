<div class="container">
	<p>¿Seguro que quieres borrar esta noticia?</p>
	<p>Desaparecerán todos los datos y no podrán recuperarse posteriormente</p>
</div>