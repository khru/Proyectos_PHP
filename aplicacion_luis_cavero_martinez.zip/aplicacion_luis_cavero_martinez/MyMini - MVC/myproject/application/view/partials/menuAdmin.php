<div class="navigationAdmin">
	<a href="<?php echo URL; ?>News/adminAll">Administrar Noticias</a>
	<a href="<?php echo URL; ?>Revistas/adminAll">Administrar Revistas</a>
</div>