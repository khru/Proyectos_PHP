<div class="navigation">
	<a href="<?php echo URL; ?>">Home</a>
	<a href="<?php echo URL; ?>News">Noticias</a>
    <a id="green" href="<?php echo URL; ?>Revistas">Revistas</a>
    <a id="in_out" href="<?php echo URL; ?>Login/salir">Salir</a>
</div>