<div class="container">
	<p>Estás identificado como <b><?= Session::get('user_nick') ?></b></p>
</div>