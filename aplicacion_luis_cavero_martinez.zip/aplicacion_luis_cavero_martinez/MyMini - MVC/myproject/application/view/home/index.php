<?php $this->layout('layout') ?>
<div class="container">
<?php $this->insert('partials/feedback') ?>
<h1>Guardabosques</h1>
<h3 style="color:green">LA REVISTA DE LOS AGENTES FORESTALES Y MEDIOAMBIENTALES DE ESPAÑA. <span style="color:orange">PROTEGIENDO NUESTRO MEDIO AMBIENTE</span></h3>
<p><i>Guardabosques</i> es una revista de tirada nacional para todos aquellos con deseos de conocer todo lo relacionado con el medio ambiente.</p>
<img src="<?=IMG . 'revista.jpg'?>" alt="Revista Guardabosques">
</div>
