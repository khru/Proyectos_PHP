<?php $this->layout('layout') ?>
<div class="container">
	<h1>ERROR 404 NOT FOUND</h1>
    <p><?= $msg ?></p>
</div>