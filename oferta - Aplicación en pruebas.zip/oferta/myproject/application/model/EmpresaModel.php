<?php
	class EmpresaModel
	{
		/**
		 * Método que obtiene el ID del campo nombre que es unique
		 * @param  String $nombre Nombre de la empresa
		 * @return Array     	  Devuelve un array
		 */
		public static function getIdByNombre($nombre)
		{
			//$conn = Database::getInstance()->getDatabase();
			$ssql = 'SELECT id FROM empresa WHERE nombre = :nombre';
			$params = [':nombre' => $nombre];
			return Database::consulta($ssql, $params, $estado = false);
			//$prepare = $conn->prepare($ssql);
			//$prepare->bindParam(':nombre', $nombre, PDO::PARAM_STR);
			//$prepare->execute();
			//return $prepare->fetch();
		}// getIdByNombre()

		/**
		 * Método que comprueba que una empresa existe a partir de un id
		 * @param  integer $id ID a comprobar
		 * @return Array
		 */
		public static function getId($id = 0)
		{
			$conn = Database::getInstance()->getDatabase();
			$ssql = 'SELECT id FROM empresa WHERE id = :id AND usuario = :usuario';
			$prepare = $conn->prepare($ssql);
			$prepare->bindParam(':id', $id, PDO::PARAM_INT);
			$prepare->bindParam(':usuario', Session::get('user_id'), PDO::PARAM_INT);
			$prepare->execute();
			return $prepare->fetch();
		}// getId()

		public static function deleteAllOfertasByEmpresa($empresa)
	   	{
	   		$conn = Database::getInstance()->getDatabase();
	    	$ssql = 'DELETE FROM oferta WHERE empresa = :empresa';
	    	$prepare = $conn->prepare($ssql);
        	$prepare->bindValue(':empresa', $empresa, PDO::PARAM_INT);
	        $prepare->execute();
	        $count = $prepare->rowCount();
	        return Database::comprobarConsulta($count);
	   	}// getAllOfertaByEmpresa

		/**
		 * Método que comprueba que el nombre de una empresa es UNIQUE
		 * @return Boolean True = si existe, False = sino existe
		 */
		public static function getNombre($nombre)
		{
			$conn = Database::getInstance()->getDatabase();
			$ssql = 'SELECT * FROM empresa WHERE nombre = :nombre';
			$prepare = $conn->prepare($ssql);
			$prepare->bindParam(':nombre', $nombre, PDO::PARAM_STR);
			$prepare->execute();
			$count = $prepare->rowCount();
	   		return Database::comprobarConsulta($count);
		}// getNombre()

		/**
	     * Método de obtención del nombre de las empresas del usuario
	     * @return Array | false Array = si existen datos, False = sino hay datos
	     */
	    public static function getNombreEmpresa()
	    {
	    	$conn = Database::getInstance()->getDatabase();
	    	$conn = Database::getInstance()->getDatabase();
	        $ssql = 'SELECT nombre as empresa FROM empresa WHERE empresa.usuario = :id';
	        $prepare = $conn->prepare($ssql);
	        $id = Session::get('user_id');
	        if (isset($id)) {
	        	$prepare->bindValue(':id', $id, PDO::PARAM_INT);
		        $prepare->execute();
		        return $prepare->fetchAll();
	        }
	        return false;
	    }// getNombreEmpresa()

		/**
		 * Método de recuperación de todas las empresas
		 * @return Array | Boolean Devuelve el array si la consulta se ejecuta, sino devuelve false
		 */
	    public static function todas()
	    {
	        $conn = Database::getInstance()->getDatabase();
	        $ssql = 'SELECT * FROM empresa WHERE usuario = :id';
	        $prepare = $conn->prepare($ssql);
	        $id = Session::get('user_id');
	        if (isset($id)) {
	        	$prepare->bindValue(':id', $id, PDO::PARAM_INT);
		        $prepare->execute();
		        return $prepare->fetchAll();
	        }
	        return false;
	    }// todas()

	    /**
	     * Método que realiza la lógica del alta de las empresas.
	     * @return Boolean 		 True = Si se ha creado la empresa correctamente
	     *                       False = Cuando ha habido un error
	     */
	    public static function alta($array)
	    {
	    	if (!$array) {
	    		// generamos el error
	    		Session::add('feedback_negative', 'No se han recibido datos');
	    		return false;
	    	}
    		// hacemos las validaciones
	    	if(EmpresaModel::validar($array)){
	    		// Saneamos el array
	    		$array = Validaciones::sanearEntrada($array);
	    		// Procedemos a la inserción de la empresa en la base de datos
	    		// Para ello preestablecemos el array que queremos insertar
	    		if (!Session::get('user_id')) {
	    			Session::add('feedback_negative', 'No tiene iniciada sesión, por lo tanto no podemos crear la empresa');
	    			return false;
	    		}
	    		$datos = [	':nombre' 		=> $array['nombre'],
	    					':web' 			=> $array['web'],
	    					':descripcion'  => $array['descripcion'],
	    					':usuario'		=> Session::get('user_id')
	    		];
	    		// devolvemos lo que la inserción nos dice
	    		return EmpresaModel::insert($datos);
	    		// procedemos a la inserción de los datos en la base de datos,
	    		// para ello tenemos un método llamado insert

	    	} else {
	    		return false;
	    	}

	    }// alta()

	    public static function borrar($id = 0)
	    {
	    	// casteamos el id
	    	$id = (int) $id;
	    	// Comprobar el que la empresa existe y es de dicho usuario
	    	if (EmpresaModel::getId($id)) {
	    		$conn = Database::getInstance()->getDatabase();
	    		$conn->beginTransaction();
	    		$estado = true;
	    		// borrar ofertas de esa empresa
	    		if (!EmpresaModel::deleteAllOfertasByEmpresa($id)) {
	    			$estado = false;
	    		}
	    		// borramos la empresa
	    		if (!EmpresaModel::delete($id)) {
	    			$estado = false;
	    		}
	    		// comprobamos el estado de la transacción
	    		if ($estado) {
	    			$conn->commit();
	    			Session::add('feedback_positive', 'La empresa ha sido borrada');
	    			return $estado;
	    		}

    			$conn->rollback();
    			Session::add('feedback_negative', 'La empresa no ha sido borrada');
    			return $estado;


	    	} else {
	    		// si la empresa no existe
	    		Session::add('feedback_negative', 'La empresa no ha sido borrada');
	    		return flase;
	    	}

	    }

	    /**
	     * Método de inserción de empresas
	     * @param  Array $array Datos a insertar en la tabla
	     * @return Boolean      True = Si se insertan bien
	     *                      False = Si no se insertan bien
	     */
	    public static function insert($array)
	    {
	    	$conn = Database::getInstance()->getDatabase();
	   		$consulta = 'INSERT INTO empresa (nombre, web, descripcion, usuario) VALUES (UPPER(:nombre), LOWER(:web), :descripcion, :usuario)';
	   		$prepare = $conn->prepare($consulta);
	   		$prepare->bindValue(':nombre', $array[':nombre'], PDO::PARAM_STR);
	   		$prepare->bindValue(':web', $array[':web'], PDO::PARAM_STR);
	   		$prepare->bindValue(':descripcion', $array[':descripcion'], PDO::PARAM_STR);
	   		$prepare->bindValue(':usuario', $array[':usuario'], PDO::PARAM_STR);
	   		$prepare->execute();
	   		$count = $prepare->rowCount();
	   		// Recogemos el id en caso de necesidad
	   		$id = $conn->lastInsertId();
	   		$_POST['id_empresa'] = $id;
			return Database::comprobarConsulta($count);
	   	}// insert()

	   	/**
	   	 * Método de borrado de empresas
	   	 * @param  Integer $id ID a borrar
	   	 * @return Boolean     True = si se borra, False = si no se borra
	   	 */
	   	public static function delete($id)
	   	{
	   		$conn = Database::getInstance()->getDatabase();
	   		$consulta = 'DELETE FROM empresa WHERE id = :id';
	   		$prepare = $conn->prepare($consulta);
	   		$prepare->bindValue(':id', $id, PDO::PARAM_INT);
	   		$prepare->execute();
	   		$count = $prepare->rowCount();
	   		return Database::comprobarConsulta($count);
	   	}// delete()

	    /**
	     * Método que valida los datos a insertar en la base de datos
	     * @param  Array $array Datos a validar
	     * @return Boolean    True = si los datos son validos, False = sino lo son
	     */
	    public static function validar($array)
	    {
	    	// Si exite el campo lo validamos

	    	// Validación del nombre
	    	if (isset($array['nombre'])) {
	    		if (($erro = Validaciones::validarNombre($array["nombre"])) !== true) {
		        	Session::addArray('feedback_negative', $erro);
		        } else {
		        	if (EmpresaModel::getNombre($array["nombre"])) {
		        		Session::add('feedback_negative', 'La empresa ya exite');
		        	}
		        }
	    	} else {
	    		Session::add('feedback_negative', 'El nombre no ha sido recicibido');
	    	}// fin de las validaciones del nombre

	    	// Validación de la web
	    	if (isset($array['web'])) {
	    		if (($erro = Validaciones::validarUrl($array["web"])) !== true) {
		        	Session::addArray('feedback_negative', $erro);
		        }
	    	} else {
	    		Session::add('feedback_negative', 'La web no ha sido recicibida');
	    	}// fin de las validaciones del apellido

	    	// Validación de la descripcion
	    	if (isset($array['descripcion'])) {
	    		if (($erro = Validaciones::validarDescripcion($array["descripcion"], 1000)) !== true) {
		        	Session::addArray('feedback_negative', $erro);
		        }
	    	} else {
	    		Session::add('feedback_negative', 'La descripcion no ha sido recicibida');
	    	}// Fin de la validación de la descripcion

	    	// Comprobación de de que no haya habido errores
	    	if (Session::get('feedback_negative')) {
	    		return false;
	    	}
	    	return true;

	    }//validar()
	}
?>