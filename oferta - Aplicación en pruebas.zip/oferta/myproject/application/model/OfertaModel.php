<?php
	class OfertaModel
	{
		/**
		 * Método de obtención de todas las ofertas
		 * @return Array | false Array = si existen datos, False = sino hay datos
		 */
	    public static function todas()
	    {
	    	//$conn = Database::getInstance()->getDatabase();
	        $ssql = 'SELECT oferta.id as id, oferta.nombre as nombre, oferta.descripcion as descripcion, requisitos, url, salario, empresa.nombre as empresa, fecha_alta as fecha FROM empresa, oferta WHERE empresa.usuario = :id AND oferta.empresa = empresa.id';
	        //$prepare = $conn->prepare($ssql);
	        $id = Session::get('user_id');
	        $params = [':id' => $id];
	        return Database::consulta($ssql, $params, $estado = false);
	        /*if (isset($id)) {
	        	$prepare->bindValue(':id', $id, PDO::PARAM_INT);
		        $prepare->execute();
		        return $prepare->fetchAll();
	        }
	        return false;*/
	    }// todas()

	    /**
	     * Método de obtención de nombre
	     * @param  String $nombre Nombre por el cual se quiere obtener la oferta
	     * @return Array          Cam
	     */
	    public static function getNombre($nombre)
	    {
	    	$conn = Database::getInstance()->getDatabase();
	    	$ssql = 'SELECT oferta.nombre FROM oferta,empresa WHERE oferta.empresa = empresa.id AND oferta.nombre = :nombre';
	    	$prepare = $conn->prepare($ssql);
        	$prepare->bindValue(':nombre', $nombre, PDO::PARAM_STR);
	        $prepare->execute();
	        return $prepare->fetchAll();
	    }// getNombre()

	    public static function getNombreEmpresa()
	    {
	    	$conn = Database::getInstance()->getDatabase();
			$ssql = 'SELECT * FROM empresa WHERE nombre = :nombre';
			$prepare = $conn->prepare($ssql);
			$prepare->bindParam(':nombre', $nombre, PDO::PARAM_STR);
			$prepare->execute();
			$count = $prepare->rowCount();
	   		return Database::comprobarConsulta($count);
	    }

	    public static function getIdEmpresaByNombre($nombre)
	    {
	    	$conn = Database::getInstance()->getDatabase();
			$ssql = 'SELECT id FROM empresa WHERE nombre = :nombre';
			$prepare = $conn->prepare($ssql);
			$prepare->bindParam(':nombre', $nombre, PDO::PARAM_STR);
			$prepare->execute();
			return $prepare->fetch();
	    }

	    public static function getOfertaById($id)
	    {
	    	$conn = Database::getInstance()->getDatabase();
	    	$ssql = 'SELECT oferta.nombre FROM oferta,empresa,usuario WHERE oferta.empresa = empresa.id AND oferta.nombre = :nombre AND empresa.usuario = :id';
	    	$prepare = $conn->prepare($ssql);
	    	if ($id = Session::get('user_id')) {
	    		$prepare->bindValue(':nombre', $nombre, PDO::PARAM_STR);
	    		$prepare->bindValue(':id', $id, PDO::PARAM_INT);
		        $prepare->execute();
		        $count = $prepare->rowCount();
		        return Database::comprobarConsulta($coun);
	    	}
	    	return false;
	    }// getOfertaById()


	    /**
	     * Método de alta de ofertas
	     * @param  Array $array Datos a insertar
	     * @return Boolean      True = si se insertan, False = sino se inserta
	     */
	    public static function alta($array)
	    {
	    	if (!$array) {
	    		// generamos el error
	    		Session::add('feedback_negative', 'No se han recibido datos');
	    		return false;
	    	}
    		// hacemos las validaciones
	    	if(OfertaModel::validar($array)){
	    		// Saneamos el array
	    		$array = Validaciones::sanearEntrada($array);
	    		// Procedemos a la inserción de la empresa en la base de datos
	    		// Para ello preestablecemos el array que queremos insertar
	    		if (!Session::get('user_id')) {
	    			Session::add('feedback_negative', 'No tiene iniciada sesión, por lo tanto no podemos crear la oferta');
	    			return false;
	    		}
	    		$fecha_alta = date('Y-m-d h:i:s');
	    		$empresa = Session::get('empresa');
	    		$empresa = $empresa['id'];
	    		$datos = [	':nombre' 		=> $array['nombre'],
	    					':descripcion'  => $array['descripcion'],
	    					':requisitos'  	=> $array['requisitos'],
	    					':url' 			=> $array['url'],
	    					':salario' 		=> $array['salario'],
	    					':empresa'		=> $empresa,
	    					':fecha_alta'	=> $fecha_alta
	    		];
	    		Session::delete('empresa');
	    		// devolvemos lo que la inserción nos dice
	    		return OfertaModel::insert($datos);
	    		// procedemos a la inserción de los datos en la base de datos,
	    		// para ello tenemos un método llamado insert

	    	} else {
	    		return false;
	    	}
	    }// alta()

	    /**
	     * Método de inserción de empresas
	     * @param  Array $array Datos a insertar en la tabla
	     * @return Boolean      True = Si se insertan bien
	     *                      False = Si no se insertan bien
	     */
	    public static function insert($array)
	    {
	    	$conn = Database::getInstance()->getDatabase();
	   		$consulta = 'INSERT INTO oferta (nombre, descripcion, requisitos, url, salario,empresa, fecha_alta) VALUES (UPPER(:nombre),  :descripcion, :requisitos, LOWER(:url), :salario, :empresa, :fecha_alta)';
	   		$prepare = $conn->prepare($consulta);
	   		$prepare->bindValue(':nombre', $array[':nombre'], PDO::PARAM_STR);
	   		$prepare->bindValue(':descripcion', $array[':descripcion'], PDO::PARAM_STR);
	   		$prepare->bindValue(':requisitos', $array[':requisitos'], PDO::PARAM_STR);
	   		$prepare->bindValue(':url', $array[':url'], PDO::PARAM_STR);
	   		$prepare->bindValue(':salario', $array[':salario'], PDO::PARAM_STR);
	   		$prepare->bindValue(':empresa', $array[':empresa'], PDO::PARAM_INT);
	   		$prepare->bindValue(':fecha_alta', $array[':fecha_alta'], PDO::PARAM_STR);
	   		$prepare->execute();
	   		$count = $prepare->rowCount();
	   		// Recogemos el id en caso de necesidad
	   		$_POST['id_oferta'] = $conn->lastInsertId();
			return Database::comprobarConsulta($count);
	   	}// insert()

	   	public static function delete($id = 0)
	   	{
	   		$id = (int) $id;
	   		$id = Validaciones::saneamiento($id);
	   		if (OfertaModel::getOfertaById($id)) {
	   			$conn = Database::getInstance()->getDatabase();
	   			$ssql = 'DELETE FROM oferta WHERE id = :id';
	   			$prepare = $conn->prepare($ssql);
	   			$prepare->bindValue(':id', $id, PDO::PARAM_STR);
	   			$prepare->execute();
	   			$count = $prepare->rowCount();
	   			if (Database::comprobarConsulta($count)) {
	   				Session::add('fedback_positive', 'La oferta ha sido satisfactoriamente borrada');
	   				return true;
	   			}
	   			Session::add('fedback_negative', 'La oferta no ha sido borrada');
	   				return false;
	   		}
	   	}// delete()

	    /**
	     * Método que valida los datos a insertar en la base de datos
	     * @param  Array $array Datos a validar
	     * @return Boolean    True = si los datos son validos, False = sino lo son
	     */
	    public static function validar($array)
	    {
	    	// Si exite el campo lo validamos

	    	// Validación del nombre
	    	if (isset($array['nombre'])) {
	    		if (($erro = Validaciones::validarNombre($array["nombre"])) !== true) {
		        	Session::addArray('feedback_negative', $erro);
		        } else {
		        	if (OfertaModel::getNombre($array['nombre'])) {
		        		Session::add('feedback_negative', 'El nombre ya existe');
		        	}
		        }
	    	} else {
	    		Session::add('feedback_negative', 'El nombre no ha sido recicibido');
	    	}// fin de las validaciones del nombre

			// Validación del descripcion
	    	if (isset($array['descripcion'])) {
	    		if (($erro = Validaciones::validarDescripcion($array["descripcion"], 1000)) !== true) {
		        	Session::addArray('feedback_negative', $erro);
		        }
	    	} else {
	    		Session::add('feedback_negative', 'La descripcion no ha sido recicibida');
	    	}// Fin de la validación del descripcion

	    	// Validación de los requisitos
	    	if (isset($array['requisitos'])) {
	    		if (($erro = Validaciones::validarRequisitos($array["requisitos"], 1000)) !== true) {
		        	Session::addArray('feedback_negative', $erro);
		        }
	    	} else {
	    		Session::add('feedback_negative', 'Los requisitos no han sido recicibidos');
	    	}// Fin de la validación de los requisitos

	    	// Validación de la url
	    	if (isset($array['url'])) {
	    		if (($erro = Validaciones::validarUrl($array["url"])) !== true) {
		        	Session::addArray('feedback_negative', $erro);
		        }
	    	} else {
	    		Session::add('feedback_negative', 'La url no ha sido recicibida');
	    	}// fin de las validaciones de la url

	    	if (isset($array['salario'])) {
	    		if (($erro = Validaciones::validarSalario($array["salario"])) !== true) {
		        	Session::addArray('feedback_negative', $erro);
		        }
	    	} else {
	    		Session::add('feedback_negative', 'El salario no ha sido recibido');
	    	}

	    	if (isset($array['empresa']) || empty($array['empresa'])) {
	    		$array['empresa'] = Validaciones::saneamiento($array['empresa']);
	    		if (!OfertaModel::getIdEmpresaByNombre($array['empresa'])) {
	    			Session::add('feedback_negative', 'La empresa no existe');
	    		} else {
	    			$empresa = OfertaModel::getIdEmpresaByNombre($array['empresa']);
	    			Session::set('empresa', $empresa);
	    			Session::set('selected', $array['empresa']);
	    		}
	    	} else {
	    		Session::add('feedback_negative', 'La empresa no ha sido seleccionada, o quizás no tenga ninguna');
	    	}

	    	// Comprobación de de que no haya habido errores
	    	if (Session::get('feedback_negative')) {
	    		return false;
	    	}
	    	return true;

	    }//validar()

	}// fin de la clase
?>