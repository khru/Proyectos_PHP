<?php $this->layout('layout-error') ?>
<div class="container">
    <p><?= $msg ?></p>
    <p>Esta página le redireccionará en 5 segundos.</p>
</div>