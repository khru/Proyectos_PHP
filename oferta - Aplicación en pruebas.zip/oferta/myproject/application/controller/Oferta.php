<?php

	class Oferta extends Controller
	{
		/**
		 * Método del constructor del controlador de ofertas
		 * @param View $view Objeto de tipo vista utilizado por Dice, para la inyección de dependencias
		 */
	    public function __construct(View $view)
	    {
	        parent::__construct($view);
	        Auth::checkAutentication();
	    }// __construct()

	    /**
	     * Método index del controlador de Oferta
	     */
	    public function index()
	    {
	    	// Obtener del modelo todas las ofertas
	    	$ofertas = OfertaModel::todas();
	    	$datos = ['ofertas' => $ofertas];
	        echo $this->view->render("ofertas/index", $datos);
	    }// index()

	    /**
	     * Método que llama a la vista del formulario
	     */
	    public function crear()
	    {
	    	if (!$_POST) {
	    		$empresa = EmpresaModel::getNombreEmpresa();
	    		$datos = ['titulo' => 'Creación de oferta', 'empresas' => $empresa];
	    		echo $this->view->render('ofertas/formularioOferta', $datos);
	    	} else {
	    		// Comprobamos $_POST
		    	if (OfertaModel::alta($_POST)) {
		    		// Generamos el mensaje de que se ha creado apropiadamente
		    		Session::add('feedback_positive', 'La oferta se a creado satisfactoriamente');
		    		// comprobamos si tiene un origen, de ser asi lo enviamos al origen
		    		// en caso contrario lo redreccionamos a /
		    		if($origen = Session::get('origen')){
		                Session::set('origen', null);
		                header ('Location:' . $origen);
		                exit();
		            }else{
		                //Existe un fedback_positive desde el modelo
		                //para mostrar en home
		                header('Location: /Oferta');
		                exit();
		            }
		    	} else {
		    		// existen errores, llamamos a la vista para mostrar los errores
		    		// Saneamos $_POST
		    		$array = Validaciones::sanearEntrada($_POST);
		    		$empresa = EmpresaModel::getNombreEmpresa();
		    		$datos = ['datos' => $array, 'empresas' => $empresa];
		    		// mostramos la vista con los datos saneados, para evitar la inyeción de código
		    		echo $this->view->render('ofertas/formularioOferta', $datos);
		    	}
	    	}

	    }// crear()

	    /**
	     * Método de borrado de una oferta
	     * @param  integer $id Id de la oferta
	     */
	    public function borrar($id = 0)
	    {
	    	OfertaModel::delete($id);
	    	header('Location: /Oferta');
	    }// borrar()

	}
?>