<?php

	class Empresa extends Controller
	{
		/**
		 * Método constructor del controlador Empresa
		 * @param View $view [description]
		 */
	    public function __construct(View $view)
	    {
	        parent::__construct($view);
	        Auth::checkAutentication();
	    }// __construct()

	    /**
	     * Método index del controlador
	     */
	    public function index()
	    {
	    	$empresas = EmpresaModel::todas();
	    	$datos = ['empresas' => $empresas];
	        echo $this->view->render("empresa/index", $datos);
	    }// index()

	    /**
	     * Método que llama a la vista del formulario de alta de Empresas
	     * y que realiza la lógica de la inserción de empresas
	     */
	    public function crear()
	    {
	    	if (!$_POST) {
	    		$datos = ['titulo' => 'Creación de empresa'];
	    		echo $this->view->render("empresa/formularioEmpresa",$datos);
	    	} else {
	    		// Comprobamos $_POST
		    	if (EmpresaModel::alta($_POST)) {
		    		// Generamos el mensaje de que se ha creado apropiadamente
		    		Session::add('feedback_positive', 'La empresa se a creado satisfactoriamente');
		    		// comprobamos si tiene un origen, de ser asi lo enviamos al origen
		    		// en caso contrario lo redreccionamos a /
		    		if($origen = Session::get('origen')){
		                Session::set('origen', null);
		                header ('Location:' . $origen);
		                exit();
		            }else{
		                //Existe un fedback_positive desde el modelo
		                //para mostrar en home
		                header('Location: /Empresa#' . $_POST['id_empresa']);
		                exit();
		            }
		    	} else {
		    		// existen errores, llamamos a la vista para mostrar los errores
		    		// Saneamos $_POST
		    		$array = Validaciones::sanearEntrada($_POST);
		    		$datos = ['datos' => $array];
		    		// mostramos la vista con los datos saneados, para evitar la inyeción de código0
		    		echo $this->view->render('empresa/formularioEmpresa', $datos);
		    	}
	    	}

	    }// crear()


	    /**
	     * Método de borrado de empresas
	     * @param  integer $id ID del registro a borrar
	     */
	    public function borrar($id = 0)
	    {
	    	EmpresaModel::borrar($id);
	    	header('Location: /Empresa');
	    	exit();
	    }// borrar()

	}// clase EMpresa
?>