<div class="acciones">
	<a href="./insertar_grupo.php">Agragar grupo</a>
</div>

