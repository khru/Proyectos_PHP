<!DOCTYPE html>
<html lang="es">
	<head>
		<meta charset="UTF-8">
		<title>Error 500</title>
		<link rel="stylesheet" href="<?= $css; ?>">
		<META HTTP-EQUIV="Refresh" CONTENT="5; URL=<?= $pagina; ?>">
	</head>
	<body>
		<section class="server-error">
			<hgroup>
				<h1><span>Error 500</span></h1>
				<h2><span>Internal Error</span></h2>
				<h3>Espere será redireccionado en 5 segundos</h3>
			</hgroup>
		</section>
	</body>
</html>
