# Ofertas
## Gestión de empresas<br/>
### Creación de una empresa a la cual quieras añadir ofertas.

Crea la empresa a la cual quieres asociar la oferta.

Edición de una empresa
* Accede al listado de empresas
* Edita la empresa que quieras.

Eliminación de una empresa
* Accede al listado de empresas
* Elimina la empresa que desees.
<br/>
**Ten en cuenta que cuando elimines una empresa, todas las ofertas de dicha empresa, seran borradas con ella.

### Creación de una oferta

Crea la empresa a la cual quieres asociar la oferta.
* Crea la oferta que desees y asociala a la empresa a la que quieras.
 Edición de una oferta
* Accede al listado de ofertas.
* Edita la oferta que desees.

Eliminación de una oferta
* Accede al listado de ofertas.
* Elimina la oferta que desees.
