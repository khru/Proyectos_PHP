<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Error 404</title>
    <!-- CSS -->
    <link href="<?php echo URL; ?>css/style.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="Refresh" content="5;url=/">
</head>
<body>
	<div>
    	<h1>Error</h1>
    	<?= $this->section('content') ?>
    </div>
</body>
</html>