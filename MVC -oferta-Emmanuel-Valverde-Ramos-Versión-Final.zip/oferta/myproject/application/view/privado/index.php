<?php $this->layout('layout') ?>

<div class="container">
    <h2>Página Privada</h2>
    <p>Sólo deberías ver esta página si estás correctamente autenticado</p>
</div>