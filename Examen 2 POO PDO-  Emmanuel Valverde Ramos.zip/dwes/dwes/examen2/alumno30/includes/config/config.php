<?php
	/**
	 * Definimos las constantes necesarias para establecer la conexión a la base de datos
	 */
	define('DB_TYPE', 'mysql');
	define('DB_HOST', 'localhost');
	define('DB_NAME', 'contacto');
	define('DB_USER', 'root');
	define('DB_PASS', '123');
	define('DB_CHARSET', 'utf8');

	/**
	 * Variable globales de enrutamiento
	 */
?>