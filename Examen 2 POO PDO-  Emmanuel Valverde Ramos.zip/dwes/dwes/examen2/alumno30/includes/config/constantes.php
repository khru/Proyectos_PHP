<?php
	$numero = "30";
	// Contantes
	define('CONFIG', '../../../dwes/examen2/alumno' . $numero . '/includes/config');
	define('CORE', '../../../dwes/examen2/alumno' . $numero . '/includes/core/');
	define('LIBS', '../../../dwes/examen2/alumno' . $numero . '/includes/libs/');
	define('MODEL', '../../../dwes/examen2/alumno' . $numero . '/includes/model/');
	// Constantes de vistas
	define('VIEW', '../../../dwes/examen2/alumno' . $numero . '/includes/view');
	define('VIEWERROR', '../../../dwes/examen2/alumno' . $numero . '/includes/view/error/');
	define('VIEWEACCION', '../../../dwes/examen2/alumno' . $numero . '/includes/view/accion/');
	define('VIEWFORMULARIO', '../../../dwes/examen2/alumno' . $numero . '/includes/view/formulario/');
	define('VIEWPLANTILLA', '../../../dwes/examen2/alumno' . $numero . '/includes/view/plantilla/');
?>