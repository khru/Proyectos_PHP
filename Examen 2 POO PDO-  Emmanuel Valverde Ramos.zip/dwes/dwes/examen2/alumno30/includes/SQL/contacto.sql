/* Borrar la base de datos si existe */
DROP DATABASE IF EXISTS contacto;
/* CREA LA BASE DE DATOS */
CREATE DATABASE contacto character set utf8 collate utf8_general_ci;
/* USA LA BASE DE DATOS */
use contacto;
/* Creamos una categoría para el usuario, esto es una futura implementación */
/* FUTURA IMPLEMENTACIÓN agenda propia */
CREATE TABLE rol (
	id_rol		int(11) not null auto_increment comment 'ID del rol del usuario',
	nombre 		varchar(100) not null comment 'Nombre del rol del usuario',
	unique(nombre),
	PRIMARY KEY(id_rol)
);
INSERT INTO rol(nombre) VALUES(UPPER('admin'));
INSERT INTO rol(nombre) VALUES(UPPER('user'));


/* Crear la tabla */
CREATE TABLE usuario(
	id_usu		int(11) not null auto_increment comment 'PK de la Base de datos',
	nombre		varchar(50) not null comment 'Nombre del usuario de la base de datos',
	apellidos	varchar(100) not null comment 'Apellidos del usuario de la BD',
	email		varchar(100) not null comment 'El email del usuario',
	pass		varchar(50) not null comment 'Contraseña del usuario (cifrada con MD5)',
	unique(email),
	PRIMARY KEY(id_usu)
);
/* INSERCIÓN DE DATOS */
insert into  usuario(nombre, apellidos, email, pass) values (UPPER('Emmanuel'),UPPER('Valverde Ramos'), LOWER('evrtrabajo@gmail.com'), MD5('Password1'));
insert into  usuario(nombre, apellidos, email, pass) values (UPPER('Emmanuel'),UPPER('Valverde Ramos'), LOWER('usuario1@gmail.com'), MD5('Password1'));

/* Crear la tabla id categoria*/
CREATE TABLE categoria(
	id_cat		int(5) not null auto_increment COMMENT 'PK de categoria',
	nombre_cat	varchar(100) not null COMMENT 'Nombre de la categoria',
	PRIMARY KEY (id_cat)
);

/* INSERCIÓN DE DATOS */
insert into  categoria(nombre_cat) values (UPPER('familia'));
insert into  categoria(nombre_cat) values (UPPER('amigos'));
insert into  categoria(nombre_cat) values (UPPER('conocidos'));

/* Crear la tabla contacto */
CREATE TABLE contacto(
	id_con		int(11) not null auto_increment comment 'PK de contacto',
	nombre		varchar(50) not null comment 'Nombre del contacto',
	apellidos	varchar(100) not null comment 'Apellidos del contacto',
	telf		varchar(13) not null comment 'telefono del contacto',
	email		varchar(100) not null comment 'email del contacto',
	direccion 	varchar(255) not null comment 'direccion del contacto',
	fech_al		date not null comment 'fecha de alta del usuario',
	id_cat		int(11) not null comment 'FK de la categoría del usuario',
	id_usu 		int(11) not null comment 'El id del usuario al que el contacto está asociado',
	unique(email, id_usu),
	FOREIGN KEY(id_cat) references  categoria(id_cat) on update cascade,
	FOREIGN KEY(id_usu) references  usuario(id_usu) on update cascade,
	PRIMARY KEY(id_con)
);
/* INSERCIÓN DE DATOS */
insert into  contacto(nombre,apellidos,telf, email, direccion, fech_al ,id_cat, id_usu) values(UPPER('Luis'), UPPER('Cavero'), '666666666', LOWER('luiscavero92@gmail.com'), 'calle no la se', '1992-06-09' ,2, 1);
insert into  contacto(nombre,apellidos,telf, email, direccion, fech_al ,id_cat, id_usu) values(UPPER('Luis'), UPPER('Cavero'), '666666666', LOWER('luiscavero92@gmail.com'), 'calle no la se', '1992-06-09' ,2, 2);
insert into  contacto(nombre,apellidos,telf, email, direccion, fech_al ,id_cat, id_usu) values(UPPER('España'), UPPER('Peña fiel'), '666666666', LOWER('luiscavelkjsldro92@gmail.com'), 'calle no la se', '1992-06-09' ,2, 1);